import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memberkedua',
  templateUrl: './memberkedua.component.html',
  styleUrls: ['./memberkedua.component.scss']
})
export class MemberkeduaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
