import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-parameter',
  templateUrl: './hr-parameter.component.html',
  styleUrls: ['./hr-parameter.component.scss']
})
export class HrParameterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
