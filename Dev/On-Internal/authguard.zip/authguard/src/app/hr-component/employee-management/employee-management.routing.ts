import { Routes } from '@angular/router';

import { EmployeeManagementComponent } from './employee-management.component';

export const EmployeeManagementRoutes: Routes = [
    {
        path: '',
        component: EmployeeManagementComponent
    },
];