import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ok-dialog',
  templateUrl: './ok-dialog.component.html',
  styleUrls: ['./ok-dialog.component.scss']
})
export class OkDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
