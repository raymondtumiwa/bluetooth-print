import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ok-task',
  templateUrl: './ok-task.component.html',
  styleUrls: ['./ok-task.component.scss']
})
export class OkTaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
