import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-added-dialog',
  templateUrl: './added-dialog.component.html',
  styleUrls: ['./added-dialog.component.scss']
})
export class AddedDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
